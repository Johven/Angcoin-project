Sample configuration files for:
```
SystemD: angcoind.service
Upstart: angcoind.conf
OpenRC:  angcoind.openrc
         angcoind.openrcconf
CentOS:  angcoind.init
macOS:    org.angcoin.angcoind.plist
```
have been made available to assist packagers in creating node packages here.

See doc/init.md for more information.
